package com.example.amarhisab

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.text.NumberFormat
import java.time.LocalDate
import java.util.Locale

data class Entry(
    val id: Long, val date: String, val kind: String,
    val amount: Double, val category: String, val note: String
)

class Db(context: Context) : SQLiteOpenHelper(context, "amar_hisab.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE entries(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL, kind TEXT NOT NULL, amount REAL NOT NULL,
            category TEXT NOT NULL, note TEXT NOT NULL DEFAULT ''
        )""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun add(date: String, kind: String, amount: Double, category: String, note: String) {
        val v = ContentValues().apply {
            put("date", date); put("kind", kind); put("amount", amount)
            put("category", category); put("note", note)
        }
        writableDatabase.insert("entries", null, v)
    }
    fun delete(id: Long) { writableDatabase.delete("entries", "id=?", arrayOf(id.toString())) }
    fun all(): List<Entry> {
        val out = mutableListOf<Entry>()
        readableDatabase.rawQuery("SELECT id,date,kind,amount,category,note FROM entries ORDER BY date DESC,id DESC", null)
            .use { c ->
                while (c.moveToNext()) out += Entry(
                    c.getLong(0), c.getString(1), c.getString(2),
                    c.getDouble(3), c.getString(4), c.getString(5)
                )
            }
        return out
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Db(this)
        setContent { AmarHisabScreen(db) }
    }
}

private val Green = Color(0xFF174D3D)
private fun money(v: Double): String =
    "৳ " + NumberFormat.getNumberInstance(Locale("en", "BD")).format(v)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AmarHisabScreen(db: Db) {
    var entries by remember { mutableStateOf(db.all()) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var kind by remember { mutableStateOf("আয়") }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("বেতন") }
    var note by remember { mutableStateOf("") }
    var month by remember { mutableStateOf(LocalDate.now().toString().take(7)) }
    var error by remember { mutableStateOf("") }
    val monthEntries = entries.filter { it.date.startsWith(month) }
    val income = monthEntries.filter { it.kind == "আয়" }.sumOf { it.amount }
    val expense = monthEntries.filter { it.kind == "ব্যয়" }.sumOf { it.amount }
    val categories = if (kind == "আয়")
        listOf("বেতন", "ব্যবসা", "টিউশনি", "অন্যান্য আয়")
    else listOf("খাবার", "বাজার", "যাতায়াত", "বাসা ভাড়া", "চিকিৎসা", "শিক্ষা", "বিল", "অন্যান্য ব্যয়")

    MaterialTheme(colorScheme = lightColorScheme(primary = Green)) {
        Scaffold(topBar = {
            TopAppBar(title = { Text("আমার হিসাব", fontWeight = FontWeight.Bold) })
        }) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 28.dp)
            ) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Green), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Wallet, contentDescription = null, tint = Color.White)
                                Spacer(Modifier.width(8.dp))
                                Text("মাসিক অবশিষ্ট", color = Color.White)
                            }
                            Text(money(income - expense), color = Color.White,
                                style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SummaryCard("মোট আয়", income, Color(0xFF168447), Modifier.weight(1f))
                        SummaryCard("মোট ব্যয়", expense, Color(0xFFC62828), Modifier.weight(1f))
                    }
                }
                item {
                    Text("নতুন হিসাব যোগ করুন", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = kind == "আয়", onClick = { kind = "আয়"; category = "বেতন" }, label = { Text("আয়") })
                        FilterChip(selected = kind == "ব্যয়", onClick = { kind = "ব্যয়"; category = "খাবার" }, label = { Text("ব্যয়") })
                    }
                    OutlinedTextField(date, { date = it }, label = { Text("তারিখ (YYYY-MM-DD)") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(amount, { amount = it }, label = { Text("টাকার পরিমাণ") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    var expanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                        OutlinedTextField(category, {}, readOnly = true, label = { Text("খাত") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth())
                        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            categories.forEach { c ->
                                DropdownMenuItem(text = { Text(c) }, onClick = { category = c; expanded = false })
                            }
                        }
                    }
                    OutlinedTextField(note, { note = it }, label = { Text("বিবরণ (ঐচ্ছিক)") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true)
                    if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
                    Button(onClick = {
                        val a = amount.toDoubleOrNull()
                        if (a == null || a <= 0 || !runCatching { LocalDate.parse(date) }.isSuccess) {
                            error = "সঠিক তারিখ ও টাকার পরিমাণ লিখুন।"
                        } else {
                            db.add(date, kind, a, category, note)
                            entries = db.all()
                            amount = ""; note = ""; error = ""
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("হিসাব সংরক্ষণ করুন") }
                }
                item {
                    HorizontalDivider()
                    Text("মাসভিত্তিক রিপোর্ট", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    OutlinedTextField(month, { month = it }, label = { Text("মাস (YYYY-MM)") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Text("সর্বমোট আয়: ${money(income)}", color = Color(0xFF168447), fontWeight = FontWeight.Bold)
                    Text("সর্বমোট ব্যয়: ${money(expense)}", color = Color(0xFFC62828), fontWeight = FontWeight.Bold)
                    Text("সঞ্চয় / অবশিষ্ট: ${money(income - expense)}", fontWeight = FontWeight.Bold)
                    Text("লেনদেনের তালিকা (${monthEntries.size})", style = MaterialTheme.typography.titleMedium)
                }
                if (monthEntries.isEmpty()) {
                    item { Text("এই মাসে কোনো হিসাব যোগ করা হয়নি।", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                } else {
                    items(monthEntries, key = { it.id }) { e ->
                        Card {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("${e.category} • ${e.date}", fontWeight = FontWeight.SemiBold)
                                    if (e.note.isNotBlank()) Text(e.note, style = MaterialTheme.typography.bodySmall)
                                }
                                Text((if (e.kind == "আয়") "+" else "−") + money(e.amount),
                                    color = if (e.kind == "আয়") Color(0xFF168447) else Color(0xFFC62828),
                                    fontWeight = FontWeight.Bold)
                                IconButton(onClick = { db.delete(e.id); entries = db.all() }) {
                                    Icon(Icons.Default.Delete, contentDescription = "মুছুন")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SummaryCard(title: String, value: Double, color: Color, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.10f))) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = color)
            Text(money(value), color = color, fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleLarge)
        }
    }
}
